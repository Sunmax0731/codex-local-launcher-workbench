# 作業開始・ローカルランチャー・Codex作業台 開発パック

| 項目 | 内容 |
| --- | --- |
| 領域 | WindowsApp |
| No. | 1 |
| 分野 | 作業開始・Codex連携 |
| アイデア | 作業開始・ローカルランチャー・Codex作業台 |
| リポジトリ名 | codex-local-launcher-workbench |
| 概要 | 集中モード、プロジェクト起動、localhost、作業見積もり、Git差分、Codex usage、セッション履歴、ChatGPT履歴、デスクトップ問い合わせをまとめる。 |
| 課題 | 作業開始時にアプリ、URL、タスク、見積もり、AIセッション状態が分散し、再開に時間がかかる。 |
| 類似サービス・アプリ | PowerToys Run, Raycast, GitHub Desktop, Codex CLI, ChatGPT |
| 差別化ポイント | Windowsデスクトップからプロジェクト起動、作業把握、Codex/ChatGPT連携まで一気通貫にする。 |

## 目的

このZIPには、`WindowsApp` 領域のアイデア `作業開始・ローカルランチャー・Codex作業台` を実装可能なプロジェクトへ落とし込むための初期ドキュメントが含まれています。

## 含まれるファイル

- START_PROMPT.md
- README.md
- 01_REQUIREMENTS.md
- 02_SPECIFICATION.md
- 03_DESIGN.md
- 04_IMPLEMENTATION_PLAN.md
- 05_TEST_PLAN.md
- 06_RELEASE_CHECKLIST.md
- metadata.json

## 使い方

1. Codexまたは他のコーディングエージェントへの最初のプロンプトとして `START_PROMPT.md` を使用する。
2. 実装前に要件、仕様、設計を確認する。
3. MVPを実装し、テスト計画に沿って検証する。
