あなたはこのアイデアの実装担当エージェントです。要件定義、仕様、設計、MVP実装、検証まで、この開発パックに沿って進めてください。

## 対象アイデア

- 親分類: Apps
- 領域: WindowsApp
- No.: 1
- 分野: 作業開始・Codex連携
- アイデア: 作業開始・ローカルランチャー・Codex作業台
- リポジトリ名: codex-local-launcher-workbench

## 元アイデア

- 概要: 集中モード、プロジェクト起動、localhost、作業見積もり、Git差分、Codex usage、セッション履歴、ChatGPT履歴、デスクトップ問い合わせをまとめる。
- 課題: 作業開始時にアプリ、URL、タスク、見積もり、AIセッション状態が分散し、再開に時間がかかる。
- 類似サービス・アプリ: PowerToys Run, Raycast, GitHub Desktop, Codex CLI, ChatGPT
- 差別化ポイント: Windowsデスクトップからプロジェクト起動、作業把握、Codex/ChatGPT連携まで一気通貫にする。

## 最初に行うこと

1. このZIP内の `01_REQUIREMENTS.md`、`02_SPECIFICATION.md`、`03_DESIGN.md` を読む。
2. 実装前に未決事項を洗い出す。
3. 既存リポジトリがある場合は、先に README、docs、Issue、テスト、現在のアーキテクチャを確認する。
4. 新規リポジトリの場合は、`04_IMPLEMENTATION_PLAN.md` のMVPから開始する。
5. 実装前に、プラットフォーム、保存方式、主要ユーザーフロー、検証方法を明記する。

## 領域別の重点事項

- 主要ユーザー、ローカル保存、権限、バックアップ、外部API境界を明確にする。
- 入力から確認、履歴、出力までの一連の流れを設計する。
- 日常利用フロー、データ復旧、プライバシーに関わる挙動を検証する。

## Done Means

- The MVP works.
- The main flow has been manually verified.
- Test or verification steps are repeatable.
- README or usage notes are updated.
- Remaining work is captured in release checklist or issues.
